package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class loginPage
{
	@FindBy(xpath="//*[@id='ctl00_MainContent_username']")
	WebElement UserName;

	@FindBy(xpath="//input[@name='ctl00$MainContent$password']")
	WebElement Password;

	@FindBy(xpath="//input[@type='submit']") 
	WebElement clickbtn;

	WebDriver wd;

	public  loginPage(WebDriver driver) {
		wd=driver;
		PageFactory.initElements(wd, this);
	}
	public void enteruser(String username) {
		UserName.sendKeys(username);
	}
	public void enterpass(String pass) {
		Password.sendKeys(pass);
	}	 
	public void clicklogin() {
		clickbtn.click();	  
	}
	public void dologin(String userdata, String passdata) 
	{
		enteruser(userdata);
		enterpass(passdata);
		clicklogin();
	}
}