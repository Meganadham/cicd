package Stepdef;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cucumber.listener.Reporter;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class LoginToApp
{
	WebDriver driver;
	Properties ps;
	@Given("^Open the browser$")
	public void open_the_browser() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna\\Desktop\\mega\\New folder (3)\\chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C:\\Users\\Krishna\\Desktop\\mega\\New folder\\webdriver\\TSACucumber\\Config\\objectRepository.properties");
		ps= new Properties();
		ps.load(fis);
	}
	@Given("^Go to url \"([^\"]*)\"$")
	public void go_to_url(String url) throws Throwable { 
		driver.get(url);
	}
	@When("^Enter the username \"([^\"]*)\"$")
	public void enter_the_username(String username) throws Throwable {
		WebElement un = driver.findElement(By.xpath(ps.getProperty("username")));
		un.sendKeys(username);
	}
	@And("^Enter the password \"([^\"]*)\"$")
	public void enter_the_password(String password) throws Throwable {
		WebElement pass = driver.findElement(By.xpath(ps.getProperty("password")));
		pass.sendKeys(password);
	}
	@When("^Click on Login button$")
	public void click_on_Login_button() throws Throwable {
		WebElement login  = driver.findElement(By.xpath(ps.getProperty("login")));
		login.click();
	}
	@Then("^Verify login is successful$")
	public void verify_login_is_successful() throws Throwable {
		WebElement order = driver.findElement(By.xpath(ps.getProperty("order")));
		if (order.isDisplayed()){
			System.out.println("Login is successful");
			Reporter.addStepLog("Login is successful");
		}
		else{
			System.out.println("Login is not Processed");
		}
	}
	
	@When("^Click on order tab$")
	public void click_on_order_tab() throws Throwable {
		WebElement od= driver.findElement(By.xpath(ps.getProperty("order")));
		od.click();
	}

	@When("^Click on View all Orders$")
	public void click_on_View_all_Orders() throws Throwable {
		WebElement allorder=driver.findElement(By.linkText("View all orders"));
		allorder.click();
	}
	@Then("^Extract the Table data$")
	public void extract_the_Table_data() throws Throwable {
		WebElement table=driver.findElement(By.xpath("//*[@id='ctl00_MainContent_orderGrid']/tbody"));
		List<WebElement> Rdata=table.findElements(By.tagName("tr"));
		System.out.println(Rdata.size());
		for(int rownum=0;rownum<Rdata.size();rownum++)
		{
			List<WebElement>coldata=Rdata.get(rownum).findElements(By.tagName("td"));
			for(int cnum=0;cnum<coldata.size();cnum++){
				System.out.print(coldata.get(cnum).getText()+"-->");
			}
			System.out.println();
		}
	}
				
}