package Utilitys;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Base.TestBase;
public class Test_Utills extends TestBase
{
	//For readily available functions. We declare function for commonly used functionalities or repeated tasks here.
	//First Login Function
	//Inherit TestBase Class to use the Properties of that class

	public static void doLogin(String usernameData, String passwordData) 
	{	
		WebElement username=  driver.findElement(By.xpath(prop_Object.getProperty("username")));
		username.sendKeys(usernameData);
		WebElement password=driver.findElement(By.xpath(prop_Object.getProperty("password")));
		password.sendKeys(passwordData);
		WebElement login =driver.findElement(By.xpath(prop_Object.getProperty("login")));
		login.click();

		WebElement order= driver.findElement(By.xpath(prop_Object.getProperty("order")));

		if(order.isDisplayed()){
			System.out.println("Login is done succesfully");
		}
		else{
			System.out.println("Login failed");
		}
		
	}
	
}	