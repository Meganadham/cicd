package Suites;
import java.util.Arrays;

import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.homepage;
import pages.loginPage;
@RunWith(Parameterized.class)
public class Verifylogin 
{
	WebDriver wd;
	loginPage lg;
	homepage hp;
	@Before
	public void Precondition()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna\\Desktop\\mega\\New folder (3)\\chromedriver.exe");
		wd=new ChromeDriver();
		lg=new loginPage(wd);
		hp=new homepage(wd);
		wd.get("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");	
	} 
	@Test
	public void Login()  
	{ 
		lg.dologin(user, pass);
		String result =	hp.VerifyOrder();
		if(result=="pass") {
			System.out.println("login is success");
		}
		else {
			System.out.println("login is not success");
		}
	}
	String user;
	String pass;
	public Verifylogin(String username, String password)
	{
		user=username;
		pass=password;
	}
	@Parameters
	public static Collection<String[]> testdata()
	{
		String data[][]=new String[2][2];
		data[0][0]="Tester";
		data[0][1]="test";
		data[1][0]="Tester1";
		data[1][1]="Test1";
		return Arrays.asList(data);
	}
}