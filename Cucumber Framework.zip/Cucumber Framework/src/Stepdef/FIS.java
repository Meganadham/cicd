package Stepdef;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FIS {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\Krishna\\Desktop\\mega\\New folder\\webdriver\\TSACucumber\\Config\\objectRepository.properties");
	Properties	ps= new Properties();
		ps.load(fis);
	System.out.println(ps.getProperty("order"));
	}

}
