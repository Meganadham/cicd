package Utills;
import java.io.File;
import java.io.IOException;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.io.FileHandler;
import Base.A_Xls_Reader;
import Base.TestBase;

public class Test_Utills extends TestBase
{
	//For readily available functions. We declare function for commonly used functionalities or repeated tasks here.
	//First Login Function
	//Inherit TestBase Class for use the Properties of that class

	public static boolean doLogin(String usernameData, String passwordData) 
	{	
		WebElement username=  driver.findElement(By.xpath(prop_Object.getProperty("username")));
		username.sendKeys(usernameData);
		WebElement password=driver.findElement(By.xpath(prop_Object.getProperty("password")));
		password.sendKeys(passwordData);
		WebElement login =driver.findElement(By.xpath(prop_Object.getProperty("login")));
		login.click();

		//		if(order.isDisplayed()){ //here is_displayed is false it will not go to else block here and it throw exception
		//			System.out.println("Login is done successfully");
		//			isLoggedin=true;
		//		}
		//		else{
		//			System.out.println("Login failed");
		//			isLoggedin=false;
		//		}
		List <WebElement> Order=driver.findElements(By.xpath(prop_Object.getProperty("order")));

		if(Order.size()!=0) {
			isLoggedin=true;
		}
		else{
			isLoggedin=false;
		}		
		return isLoggedin;
	}
	public static boolean IsSkip(String inputTestCase ) 
	{
		data=new A_Xls_Reader(System.getProperty("user.dir")+"\\src\\Inputs\\AutomationSuit.xlsx");
		int rowCount=data.getRowCount("Testcase");
		int columnCount=data.getColumnCount("Testcase");
		for(int rowNumber=2;rowNumber<=rowCount;rowNumber++ ) 
		{
			if(inputTestCase.equals(data.getCellData("Testcase",0, rowNumber))) 
			{
				if(data.getCellData("Testcase",2,rowNumber).equals("Y")){
					return true;
				}
				else {
					return false;
				}
			}
		}
		return false;
	}
	public static String [][] getData(String sheetName)
	{
		data=new A_Xls_Reader(System.getProperty("user.dir")+"\\src\\Inputs\\AutomationSuit.xlsx");
		int rowCount=data.getRowCount(sheetName);
		int colCount=data.getColumnCount(sheetName);
		System.out.println("SheetName is: " +sheetName);
		System.out.println("Number of rows:" +rowCount);
		System.out.println("Number of columns:" +colCount);
		String testCaseData[][]=new String[rowCount-1][colCount];

		//testCaseData[0][0]="Tester";
		for(int rowNumber=2;rowNumber<=rowCount;rowNumber++)
		{
			for(int colnumber=0;colnumber<colCount;colnumber++) 
			{
				testCaseData[rowNumber-2][colnumber]=data.getCellData(sheetName, colnumber, rowNumber);						
			}				
		}
		return testCaseData;			
	}
	public static void getScreenshot(String filename) throws IOException
	{
		File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileHandler.copy(f, new File(System.getProperty("user.dir")+"\\src\\Output"+ filename+".png"));
	}
}	