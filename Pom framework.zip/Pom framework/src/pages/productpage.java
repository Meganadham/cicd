package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class productpage 
{
	By product=By.xpath("//select[@name='ctl00$MainContent$fmwOrder$ddlProduct']");
	WebDriver wd;
	public  productpage(WebDriver driver) {
		wd=driver;
	}
	public void productClick(String dropvalues) 
	{
		wd.findElement(product).sendKeys(dropvalues);
	}
}

