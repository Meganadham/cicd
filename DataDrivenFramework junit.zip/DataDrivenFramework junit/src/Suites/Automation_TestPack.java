package Suites;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
@RunWith(Suite.class)
@SuiteClasses({ Contact_Us_TestCase.class, Forgot_password_Testcase.class, Login_Testcase.class, Registration_Testcase.class })
public class Automation_TestPack 
{

}
/*
ANT Build Integration Tool:
"ANT"  is one OF build integration tool owned by Apache, what ever Eclipse does like clean, Compile, build, run, ANT supports for us.
So, without Eclipse, in Command Prompt itself we can run.
Advanced Build tools are Maven, Gradle.
ANT is a configuration tool, not an installation software.
ANT is a ZIP file, download from URL->https://ant.apache.org/bindownload.cgi
C:\Users\HP>ant -version
ANT build integration tool checks for "build.xml" file to execute.
Maven will check  for "pom.xml" file.
Any build integration tool will have one xml file as point of contact.
Ant won't see our project , it will only check our xml file and run, so we need to configure all our projects in build.xml only.
Whenever triggered ant, it refers only the xml file.
We need to configure this xml file according to our requirements.
In the given build file change the project name, jars location, output location, java version.

1.<project name="Data Driven Automation framework" default="usage" basedir=".">  
2.<property name="ws.jars" value="C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework\src\Libraries"/>
3.<property name="test.reportsDir" value="C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework\src\Output"/>
4.<include name="Suites/Automation_TestPack.class" />
5.target="1.8"

Go to Command prompt 
--------------------
C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework>ant 
C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework>ant clean
C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework>ant compile
C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework>ant run


C:

cd C:\Users\Krishna\Desktop\mega\New folder\webdriver\DataDrivenFramework

ant clean compile run

pause

*/