package Suites;
import java.io.IOException;

import org.junit.BeforeClass;
import org.testng.Assert;
import org.testng.annotations.Test;

import Base.TestBase;
import Utills.Test_Utills;
public class Contact_Us_TestCase extends TestBase
{
	@BeforeClass
	public void pre_Condition() throws IOException
	{
		doInitialization();
		boolean runCondition= Test_Utills.IsSkip("Contact_US_TestCase");
		if(runCondition==false) {
			Assert.assertTrue(false);
		}
	}	
	@Test
	public void Contactus() 
	{
		System.out.println("contact us page");
	}
}