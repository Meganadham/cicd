package Methods;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
public class AutoIT 
{
	public static void main(String[] args) throws IOException, InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna\\Desktop\\mega\\New folder (3)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://demo.guru99.com/test/upload/");
		WebElement upload = driver.findElement(By.xpath("//*[@id=\"uploadfile_0\"]"));
		//upload.sendKeys("C:\\Users\\Krishna\\Desktop\\mega\\code selenium\\b start at march1\\New folder (3)\\AutoIt.exe");;
		Actions act=new Actions(driver);
		act.moveToElement(upload).click().build().perform();

		Thread.sleep(5000);
		Runtime.getRuntime().exec("C:\\Users\\Krishna\\Desktop\\mega\\code selenium\\b start at march1\\New folder (3)\\AutoIt.exe");
	}
}
/*
to Automate the desktop based application we can use AutoIt tool
go to path " C:\Program Files (x86)\AutoIt3\SciTE " and click SciTE file ->it is editor for develop AutoIt program
go to path "C:\Program Files (x86)\AutoIt3" and click Au3Info file and drag the finder tool.
drop in desktop application show filename text box when click on upload file  
syntax:
open editor type-> controlFocus( "title" "text", "controlId")
EX:
ControlFocus("open","","Edit1")
here open=title and ""=text and  Edit1->class and instance & Button1->class and instance
upload file path =C:\Users\Krishna\Desktop\mega\code selenium\b start at march1\New folder (3)\cookies.png
ex:
ControlFocus("Open","","Edit1")
ControlSetText("Open","","Edit1","C:\Users\Krishna\Desktop\mega\code selenium\b start at march1\New folder (3)\cookies.png")
ControlClick("Open","","Button1")

After save as AutoIt.au3 (all file) and right click on file and click compile script we got (.EXE) file
Runtime.getRuntime().exec("C:\\Users\\Krishna\\Desktop\\mega\\code selenium\\b start at march1\\New folder (3)\\AutoIt.exe");

we need give EXE file in program

*/