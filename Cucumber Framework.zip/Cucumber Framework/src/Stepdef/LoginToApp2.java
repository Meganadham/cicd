package Stepdef;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cucumber.listener.Reporter;

import cucumber.api.DataTable;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class LoginToApp2
{
	@Before
	public void test_preCondition()
	{
		System.out.println("before Test");
	}
	
	WebDriver driver;
	Properties ps;
	@Given("^Open the browsers$")
	public void open_the_browsers() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna\\Desktop\\mega\\New folder (3)\\chromedriver.exe");
		driver = new ChromeDriver();
		FileInputStream fis = new FileInputStream("C:\\Users\\Krishna\\Desktop\\mega\\New folder\\webdriver\\TSACucumber\\Config\\objectRepository.properties");
		ps= new Properties();
		ps.load(fis);
	}
	@Given("^Navigate to url$")
	public void navigate_to_url(DataTable dataTable) throws Throwable {
		List<String> credentials=dataTable.asList(String.class);
		String url=credentials.get(0);
		driver.get(url);
	}
	@When("^I do the Login$")
	public void i_do_the_Login(DataTable dataTable) throws Throwable {
		
		List<List<String>> credentials=dataTable.raw();
		String userName=credentials.get(0).get(0);
		String password=credentials.get(0).get(1);//0->rows, 1->column 
		
		WebElement un = driver.findElement(By.xpath(ps.getProperty("username")));
		un.sendKeys(userName);
		WebElement pass = driver.findElement(By.xpath(ps.getProperty("password")));
		pass.sendKeys(password);
		WebElement login  = driver.findElement(By.xpath(ps.getProperty("login")));
		login.click();
	}
	@Then("^Verify the login$")
	public void verify_the_login() throws Throwable {
		WebElement order = driver.findElement(By.xpath(ps.getProperty("order")));
		if (order.isDisplayed()){
			System.out.println("Login is successful");
			//Reporter.addStepLog("Login is successful");
		}
		else{
			System.out.println("Login is not Processed");
		}
	}			
}