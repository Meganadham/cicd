package pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class  RegistrationPage
{
	@FindBy(xpath="//select[@name='ctl00$MainContent$fmwOrder$ddlProduct']")
	WebElement product;

	@FindBy(xpath="//*[@id=\"ctl00_MainContent_fmwOrder_txtName\"]")
	WebElement customer;

	@FindBy(xpath="//*[@id=\"ctl00_MainContent_fmwOrder_TextBox5\"]")
	WebElement zip;

	WebDriver wd; 
	public  RegistrationPage(WebDriver driver) {
		wd=driver;
		PageFactory.initElements(wd, this);
	}
	public void productClick(String dropvalues) {
		product.sendKeys(dropvalues);
	}
	public void Customer(String data) {
		customer.sendKeys(data);
	}
	public void Zip(String data) {
		zip.sendKeys(data);
	}
	public void doRegister(String dropdown, String customer, String zip) {
		productClick(dropdown);
		Customer(customer);
		Zip(zip);
	}	
}