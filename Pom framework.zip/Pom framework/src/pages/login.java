package pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class login 
{
	 By UserName=By.xpath("//*[@id='ctl00_MainContent_username']");
	 By Password=By.xpath("//input[@name='ctl00$MainContent$password']");
	 By click=By.xpath("//input[@type='submit']");
	
	 WebDriver wd;
	 public  login(WebDriver driver) {
		 wd=driver;
	 }
	 public void enteruser(String username) {
		 wd.findElement(UserName).sendKeys(username);
	 }
	 public void enterpass(String pass) {
		 wd.findElement(Password).sendKeys(pass);
	 }	 
	 public void clicklogin() {
		 wd.findElement(click).click();	 
	 }
}
