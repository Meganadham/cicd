package Suites;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import Base.TestBase;
import Utills.Test_Utills;

@RunWith(Parameterized.class)
public class Login_Testcase extends TestBase
{
	String userName;
	String password;
	String TypeOfData;
	public Login_Testcase(String Username,String Password, String DataType)
	{
		userName=Username;
		password=Password;
		TypeOfData=DataType;
	}
	@Before
	public void pre_Condition() throws IOException {
		doInitialization();
		boolean runCondition= Test_Utills.IsSkip("Login_Testcase");
		if(runCondition==false) {
			Assert.assertTrue(false);
		}
	}
	@Test
	public void verify_Login() throws IOException 
	{
		driver.get(prop_Config.getProperty("url"));
		Test_Utills.doLogin(userName,password);// from utills class

		if(isLoggedin==false&TypeOfData.equals("Positive")) {
			System.out.println("Login Test case is not passed for the positive test data, hence it is a bug");
			Test_Utills.getScreenshot("LoginFailure1");
			Assert.assertTrue(false);
		}
		else if(isLoggedin==true&TypeOfData.equals("Negative")) {
			System.out.println("Login Test Case is passed for the Negative test data, hence it is a bug");
			Test_Utills.getScreenshot("LoginFailure2");
			Assert.assertTrue(false);
		}
//		 if(isLoggedin==true) {
//			 System.out.println("Logged in Successfully");
//		 }
//		 
//		 else {
//			 System.out.println("Logged in UnSuccessfull");
//		 }
	}
	/*@After
	public void post_Condition() {
		driver.close(); 
	}*/
	@Parameters
	public static Collection<String[]> testData()
	{	/*
	    String data[][]= new String[1][2];
		data[0][0]="Tester";
		data[0][1]="test";
	 */
		String data[][]=Test_Utills.getData("Login_Testdata");
		return Arrays.asList(data);
	}	
}