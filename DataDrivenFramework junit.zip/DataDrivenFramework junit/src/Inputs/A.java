package Inputs;
public class A 
{
	public static void main(String[] args) 
	{

	}
}