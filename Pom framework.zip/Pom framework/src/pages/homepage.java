package pages;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
public class homepage
{
	@FindBy(xpath="//*[@id='ctl00_menu']/li[3]/a")
	List <WebElement> orderList;
	
	@FindBy(xpath="//*[@id='ctl00_menu']/li[3]/a")
	WebElement orders;

	WebDriver wd;

	public  homepage(WebDriver driver) {
		wd=driver;
		PageFactory.initElements(wd, this);
	}
	public String VerifyOrder() 
	{
		//boolean Orders = order.isDisplayed();
		if(orderList.size()!=0) {
			String results="pass";
			return results;
		}
		else {
			String results="fail";
			return results;
		}
	}
	public void Clickorder() {
		orders.click();
	}
}