package Base;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
public class TestBase 
{
	public static WebDriver driver;
	public static Properties prop_Object;
	public static Properties prop_Config;
	public static boolean isLoggedin; 
	public static A_Xls_Reader data;
	//Commonly used variables
	//Store all Variables in TestBase class only, which can be used across the automation Pack
	//Declare and initialize the Variables in TestBase class like Web driver, Properties, Excel, JDBC
	public static void doInitialization() throws IOException 
	{
		if(driver==null) 
		{
			data=new A_Xls_Reader(System.getProperty("user.dir")+"\\src\\Inputs\\AutomationSuit.xlsx");
			FileInputStream fis_Object=new FileInputStream(System.getProperty("user.dir")+"\\src\\Configuration\\ObjectRepository.properties");
			FileInputStream fis_Config=new FileInputStream(System.getProperty("user.dir")+"\\src\\Configuration\\Config.properties");
			prop_Object=new Properties();
			prop_Config=new Properties();
			prop_Object.load(fis_Object);
			prop_Config.load(fis_Config);
			String browserName=prop_Config.getProperty("browsername");

			if(browserName.equals("Chrome".trim())){
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\src\\Libraries\\chromedriver.exe");
				driver=new ChromeDriver();
			}	
			else if(browserName.equals("ie")){
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\src\\Libraries\\IEDriverServer.exe");
				driver=new InternetExplorerDriver();
			}
		}
	}
	public static WebElement get_Objects(String xpathValue)	//this method will return a WebElement
	{
		return driver.findElement(By.xpath(prop_Object.getProperty(xpathValue)));
	}
}
/*
Base: Commonly used variables can be declared here. Store all Variables in TestBase class only, which can be used across the automation Pack.

Configuration:We can have all properties file and for objects of application.

Inputs : Will Contain TestCases, TestData, Where we have an excel Sheet to write TestCAses and Testdata.

Libraries: All the Jarfiles required, will have in referenced Libraries.

Output:Reports, We store reports here like ScreenShots, logs etc.,

Suites: Collection of all test cases, we build Automation Suite for all the test cases in the suite and execute.In this Package we have all TestCases.

Utilities:For readily usable functions. We declare function for common functionaities/repeated tasks here.
Ex: doLogin is common for all test cases , we write the function here and use it in other classes.

*/