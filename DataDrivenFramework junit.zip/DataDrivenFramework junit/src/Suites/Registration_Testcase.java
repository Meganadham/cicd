package Suites;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.WebElement;
import Base.TestBase;
import Utills.Test_Utills;
@RunWith(Parameterized.class)
public class Registration_Testcase extends TestBase 
{
	String product;
	String quantities;
	String Cname;
	String Street;
	String CityName;
	public Registration_Testcase(String products,String quantity, String name, String Streetname, String City)
	{
		product=products;
		quantities=quantity;
		Cname=name;
		Street=Streetname;
		CityName=City;
	}
	@Before
	public void pre_Condition() throws IOException
	{
		doInitialization(); 
		boolean runCondition= Test_Utills.IsSkip("Registration_Testcase");
		if(runCondition==false) {
			Assert.assertTrue(false);
		}
	}
	@Test
	public void do_Registration() throws InterruptedException 
	{
		driver.get(prop_Config.getProperty("url"));
		Test_Utills.doLogin("Tester","test");	

		//we can initialize WebElement in Base class
		WebElement Orders=  get_Objects("order");
		Orders.click();
		Thread.sleep(1000);

		WebElement products=get_Objects("pd");
		products.sendKeys(product);
		WebElement qt=get_Objects("qt");
		qt.sendKeys(quantities);
		WebElement cn= get_Objects("cn");
		cn.sendKeys(Cname);
		WebElement st= get_Objects("st");
		st.sendKeys(Street);
		WebElement city=get_Objects("city");
		city.sendKeys(CityName);

		WebElement zip =get_Objects("zip");
		zip.sendKeys("517503");
		WebElement card=get_Objects("card");
		card.click();
		WebElement cardnum=get_Objects("cardnum");
		cardnum.sendKeys("12345678901234");
		WebElement exp=get_Objects("exp");
		exp.sendKeys("23/23");
		WebElement pr=get_Objects("pr");
		pr.click();
		WebElement s=get_Objects("s");
		
		if(s.isDisplayed()){
			System.out.println("Order processed");
		}
		else{
			System.out.println("Order not processed");
		}
	}
	/*
	@After
	public void Post_Condition() {
		driver.close();
	}
	*/
	@Parameters
	public static Collection<String[]> testData()
	{
		String data[][]=Test_Utills.getData("Registration_Testdata");
		return Arrays.asList(data);
	}
}