package Base;
public class Rough 
{
	public static void main(String[] args) 
	{
		System.out.println(System.getProperty("user.dir"));//get relative path 
		
		A_Xls_Reader data=new A_Xls_Reader(System.getProperty("user.dir")+"\\src\\Inputs\\AutomationSuit.xlsx");
		System.out.println(data.getCellData("Testcase", 1, 1));
		int rowCount=data.getRowCount("Testcase");
		int columnCount=data.getColumnCount("Testcase");
		System.out.println("Number of rows :"+ rowCount);
		System.out.println("Number of Columns :"+ columnCount);

		//String inputTestCase="Login_Testcase";
		String inputTestCase="Registration_Testcase";

		for(int rowNumber=2;rowNumber<=rowCount;rowNumber++ ) 
		{
			if(inputTestCase.equals(data.getCellData("Testcase",0, rowNumber))) 
			{
				if(data.getCellData("Testcase",2,rowNumber).equals("Y")) {
					System.out.println("Run the TestCase");
				}
				else {
					System.out.println("Skip the TestCase");
				}
			}
		}
	
	}
}
