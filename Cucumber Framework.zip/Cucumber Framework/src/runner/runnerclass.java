package runner;
import org.junit.runner.RunWith;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features = "Feature",
		glue="Stepdef",
		dryRun=false,
	  //plugin= {"com.cucumber.listener.ExtentCucumberFormatter:Report/AutomationReport.html"}
	    tags= {"@DataTable"} 
		)
public class runnerclass 
{
}
/*
Scenario is used to when one test data is sent.
Scenario Outline->is used to pass more test data in the Feature 
Number of columns declared under Examples keyword, we should give those in the respective line in steps.
We can also pass /add multiple test data in the Examples. By adding in new columns with | Symbols

logger->Reporter.addStepLog("Login is successful");
	
using tags
----------
feature files ->Possibilities to execute the all Scenarios so use tags
Running all scenarios in the feature files
Running only one scenarios from multiple Feature files
Running more than one scenario from all feature files
Running more than one scenario from one feature file
Excluding a Scenario with ~ symbol.

*/