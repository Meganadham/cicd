package runner;
/*
There are two ways to pass the test data 
1. Using Scenario Outline->We can pass the data from feature file.
2. Using Data Table 
ex:
List<List<String>> credentials=dataTable.raw();
String userName=credentials.get(0).get(0);
		
Test runner file is used for execution, test runner file connects the feature and corresponding Stepdefinition, 
Test runner file has Feature paramaters.
In test runner file we have 2 options one is @RunWith(Cucumber.class) and other is @CucumberOptions 
In @CucumberOptions  we have to give 2 parameters one is features in which we give exact name of our Feature folder
and second is glue , glue connects our stepdefinition package.
glue has the location of step definition in curly brackets {} , give the package name of stepdefinition
glue refers to step definition file,which represents programming code

We can run this testrunner file right click run as Junit test and we will get all the implemenation steps.
now we can copy paste these steps in the Stepdefinition package class.
these steps will have corresponding tags and methods which we have already created in the feature file.

In real time, we shouldn't hard code the testdata, URL, Locators.
As locators are the components which will dynamically change, We can't modify script each and every time, the code should be constant.
With the help of properties file we can Store the URL and Locators, Create a Properties file in the project as below naming"ObjectRepository"
Declare	Properties ps; globally so that it can be used in all other methods.
Now with the help of  ps.getProperty(""), we can pass the variables stored for respective locators, there by optimizing the code without hotcode
the locators in methods directly.
For now the locator used is xpath for all WebElements.
scenario and scenario outline
-----------------------------
to pass the test data we need to give a key word called Scenario Outline and this helps to include test data
write keyword Examples and below line give the variables with pipe Symbol "|"separating them, and pass the test data in same manner.
Also In the respective line map the variable at the end using tags (sample: Given Go to url "<url>")
Examples: 
|url|username|password|
|http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx|Tester|test|

Randomn data generation and date generation concepts
====================================================
# |A-Z|a-z|0-9|@,.[1].gmail.com|

Background keyword is used in a feature file and is applicable only for the feature file where its specified
@Before is used in the implementation file and the method will execute for all the feature files

@Before
	public void test_pre()
	{
		System.out.println("Test at before");
	}

@Before can be used along with scenario tag also and it will execute before that specified scenario

@Before("@Regression")
	public void test_pre()
	{
		System.out.println("Test at before");
	}


*/