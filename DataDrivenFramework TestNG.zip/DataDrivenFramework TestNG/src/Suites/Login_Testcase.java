package Suites;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Base.TestBase;
import Utills.Test_Utills;
public class Login_Testcase extends TestBase
{
	@BeforeClass
	public void pre_Condition() throws IOException {
		doInitialization();
		boolean runCondition= Test_Utills.IsSkip("Login_Testcase");
		if(runCondition==false) {
			Assert.assertTrue(false);
		}
	}
	@Test(dataProvider="testData")
	public void verify_Login(String userName,String password, String TypeOfData ) throws IOException 
	{
		driver.get(prop_Config.getProperty("url"));
		Test_Utills.doLogin(userName,password);// from utills class

		if(isLoggedin==false&TypeOfData.equals("Positive")) {
			System.out.println("Login Test case is not passed for the positive test data, hence it is a bug");
			Test_Utills.getScreenshot("LoginFailure1");
			Assert.assertTrue(false);
		}
		else if(isLoggedin==true&TypeOfData.equals("Negative")) {
			System.out.println("Login Test Case is passed for the Negative test data, hence it is a bug");
			Test_Utills.getScreenshot("LoginFailure2");
			Assert.assertTrue(false);
		}
	}
	@DataProvider
	public  String[][] testData()
	{	
		String data[][]=Test_Utills.getData("Login_Testdata");
		return data;
	}	
}