package Suites;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.RegistrationPage;
import pages.homepage;
import pages.loginPage;

@RunWith(Parameterized.class)
public class VerifyRegistration 
{
	WebDriver wd; 
	loginPage lg;
	homepage hp;
	RegistrationPage reg;	
	@Before
	public void Precondition() throws IOException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Krishna\\Desktop\\mega\\New folder (3)\\chromedriver.exe");
		wd=new ChromeDriver();		
		lg=new loginPage(wd);
		hp=new homepage(wd);
		reg=new RegistrationPage(wd);
		wd.get("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");
	}
	@Test
	public void Login() 
	{
		lg.enteruser("Tester");
		lg.enterpass("test");
		lg.clicklogin();
		hp.Clickorder();
		reg.doRegister(amount, name, number);
		//reg.doRegister("MyMoney", "king", "34");
	}
	String amount;
	String name;
	String number;
	public VerifyRegistration(String username, String password, String num)
	{
		amount=username;
		name=password;
		number=num;
	}
	@Parameters
	public static Collection<String[]> testdata()
	{
		String data[][]=new String[2][3];
		data[0][0]="MyMoney";
		data[0][1]="Test";
		data[0][2]="1235";
		data[1][0]="MyMoney";
		data[1][1]="raj";
		data[1][2]="567";
		return Arrays.asList(data);
	}
}